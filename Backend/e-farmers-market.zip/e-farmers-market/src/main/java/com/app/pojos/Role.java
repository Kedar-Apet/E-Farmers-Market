package com.app.pojos;

import java.io.Serializable;

public enum Role implements Serializable{
BUYER,PRODUCER
}
