package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ErrorResponse;
import com.app.pojos.User;
import com.app.service.IUserService;

@RestController
@RequestMapping("/user")
@CrossOrigin
public class UserController {
	@Autowired
	private IUserService userService;

	@PostMapping("/register")
	public ResponseEntity<?> addNewUserDetails(@RequestBody User transientUser) {
		System.out.println("in add user " + transientUser.getRole());
		// invoke service layers method for (persistence)saving user details
		try {
			return new ResponseEntity<>(userService.addUser(transientUser), HttpStatus.CREATED);
		} catch (RuntimeException e) {
			System.out.println("Err in add " + e);
			return new ResponseEntity<>(new ErrorResponse("Adding user failed", e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	@PostMapping("/login")
	public ResponseEntity<?> authentication(@RequestBody User user) {
		try {
		System.out.println("User login");
		return new ResponseEntity<>(   userService.userLogin(user.getEmail(), user.getPassword()),HttpStatus.FOUND);
		}
		catch(RuntimeException e) {
			System.out.println("Err in finding "+e);
			return new ResponseEntity<>(new ErrorResponse("No user Found" , e.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}