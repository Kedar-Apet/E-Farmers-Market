package com.app.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.UserRepository;
import com.app.pojos.User;

@Transactional
@Service
public class UserServiceImpl implements IUserService {
	@Autowired
	private UserRepository userRepo;
	
	
	@Override
	public User userLogin(String email, String password) {
		
		return userRepo.findByEmailAndPassword(email,password);
	}
	@Override
	public User addUser(User user) {
		
		return userRepo.save(user);
	}

	@Override
	public String deleteUser(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getDetails(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User updateDetails(User detachedUser) {
		// TODO Auto-generated method stub
		return null;
	}
}
